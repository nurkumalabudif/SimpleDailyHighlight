import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class TodoService {
    apiEndPoint;
    currentSettings;
  
    constructor(
      private http: HttpClient,
    ) {}

    addName(name): Observable<Object> {
        const paramData = {
            name: name
        };
        return this.http.post(
            'localhost',
            paramData
        );
    }

    addTodo(id, todoDesc): Observable<Object> {
        const paramData = {
            todoDesc: todoDesc,
            isActive: 1
        };
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type':  'application/json',
                'Access-Control-Allow-Origin': 'http://127.0.0.1:4200',
                'Access-Control-Allow-Headers': 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers'
            })};
        return this.http.put(
            'https://crudcrud.com/api/3c059f0c7a27445599c299c0d1b3dffb/todo' + id,
            paramData,
            httpOptions
        );
    }
}